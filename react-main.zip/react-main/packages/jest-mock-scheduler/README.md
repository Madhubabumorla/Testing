# `jest-mock-scheduler`

Jest matchers and utilities for testing the `scheduler` package.

This package is experimental. APIs may change between releases.